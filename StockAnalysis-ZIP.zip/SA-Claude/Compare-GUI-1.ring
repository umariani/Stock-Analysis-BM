// Compare Quote.ini files for diffrences. Added/Deleted
// Bert Mariani 2024-09-18
//
// ----------------------------------------------------------------

load "stdlibcore.ring"
load "guilib.ring"

# --------------------------
  
# --------------------------

# ---  Global Data Containers
aList1 = []
aList2 = []

NotInList1 = []
NotInList2 = []

aNewList1 = []
aNewList2 = []

cFile1 = "one"         // Long path name
cFile2 = "two"
cInFileName1 = "one"   // Short filename
cInFileName2 = "two" 


# --- Global Objects
win           = null
oChartWidget  = null
txtLog        = null    // Left Panel
txtLog2       = null    // Right Panel

btnRun         = null
btnBrowse1     = null
btnBrowse2     = null
txtTickerFile1 = null
txtTickerFile2 = null 
App            = null

# ------------------------------

# ==============================

// There are 19 predefined QColor objects: 
// white, black, red, darkRed, green, darkGreen, blue, darkBlue, cyan, darkCyan, 
// magenta, darkMagenta, yellow, darkYellow, gray, darkGray, lightGray, color0 


# Constants for Styling
C_STYLE_DARK = "
    QWidget {
        background-color: #2b2b2b;
        color: #000000 ;             // #ffffff;
        font-family: 'Segoe UI', sans-serif;
        font-size: 14px;
    }
    QPushButton {
        background-color: #007acc;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        color: white;
        font-weight: bold;
    }
    QPushButton:hover {
        background-color: #005999;
    }
    QPushButton:pressed {
        background-color: #004080;
    }
    QLineEdit, QComboBox {
        background-color: #3c3c3c;
        border: 1px solid #555;
        padding: 4px;
        border-radius: 3px;
        color: white;
    }
    QFrame {
        border: 1px solid #555;
        border-radius: 5px;
        margin-top: 10px;
        padding: 5px;
        background-color: #333;
    }
    QLabel {
        font-weight: bold;
        color: #cccccc;
    }
"

# =====================================
# =====================================

func main
 App = new QApp
 {
        
    win = new QWidget() {
        //setWinIcon(self,"appicon.png")
        setWindowTitle("Compare Quotes.ini Files")
        resize(900, 700)
        setStyleSheet(C_STYLE_DARK)

        # --- Layouts ---
        mainLayout     = new QVBoxLayout()
        controlsLayout = new QHBoxLayout()
        contentLayout  = new QHBoxLayout()

        # --- Controls Section ---
        groupControls = new QFrame( win,0) {
            setFrameShape(QFrame_StyledPanel)
            
            # Main layout for the frame (Vertical to hold Title + Controls)
            frameLayout = new QVBoxLayout() {
                
                # Title
                lblTitle = new QLabel( win) {
                    setText("Configuration")
                    setStyleSheet("color: #007acc; font-weight: bold;")
                }
                addWidget(lblTitle)

                # Controls Layout (Horizontal)
                controlsLayoutInner = new QHBoxLayout() {
                    
  
                    //---------------------

                    # --- Ticker File: Globals: txtTickerFile1 = null
					
                    addWidget(new QLabel(win){setText("Ticker File 1:")})
                    txtTickerFile1 = new QLineEdit(win){setText("Quotes-Mega-32.ini")}
                    addWidget(txtTickerFile1)
                    
                                                            
                    btnBrowse1 = new QPushButton(win){setText("Browse1...")}
                    btnBrowse1.setStyleSheet("background-color: yellow;")
                    btnBrowse1.setClickEvent("browseFile1(this)")
                    addWidget(btnBrowse1)
                                        
                    # -----------------------
					
					# --- Ticker File: Globals: txtTickerFile2 = null
                    addWidget(new QLabel(win){setText("Ticker File 2:")})
                    txtTickerFile2 = new QLineEdit(win){setText("Quotes-Mega-12.ini")}
                    addWidget(txtTickerFile2)
                    
                                                            
                    btnBrowse2 = new QPushButton(win){setText("Browse2...")}
                    btnBrowse2.setStyleSheet("background-color: yellow;")
                    btnBrowse2.setClickEvent("browseFile2(this)")
                    addWidget(btnBrowse2)
                                        
                    # -----------------------

                    # Run Quotes Button
                    btnQuotes = new QPushButton(win){setText("GetQuotes")}
                    btnQuotes.setStyleSheet("background-color: cyan;")
                    btnQuotes.setClickEvent("GetQuotes()")
                    addWidget(btnQuotes)

                    ### # Run Analysis Button
                    ### btnRun = new QPushButton(win){setText("Run Analysis")}
                    ### btnRun.setStyleSheet("background-color: cyan;")
                    ### btnRun.setClickEvent("YearlyReturns()")
					### btnRun.setEnabled(true)   // Disable until Get Quotes done
                    ### addWidget(btnRun)
                    
                    //-------------------
                    //------------------                
	
                }
                addLayout(controlsLayoutInner)
            }
            setLayout(frameLayout)
        }

        # --- Content Section ---
        
        # Left: Data/Log
        groupData = new QFrame(win,0) {
            setFrameShape(QFrame_StyledPanel)
            frameLayout = new QVBoxLayout() {
                lblTitle = new QLabel(win) {
                    setText("Quotes.Ini Differences")
                    setStyleSheet("color: #007acc; font-weight: bold;")
                }
                addWidget(lblTitle)

                txtLog = new QTextEdit(win){setReadOnly(true)setText("Ready-1 to start...")}
                addWidget(txtLog)
            }
            setLayout(frameLayout)
        }

        # Right: Chart Area
        groupChart = new QFrame(win, 0) {
            setFrameShape(QFrame_StyledPanel)
            frameLayout = new QVBoxLayout() {
                lblTitle = new QLabel(win) {
                    setText("New Quotes.ini Combo")
                    setStyleSheet("color: #007acc; font-weight: bold;")
                    setMaximumHeight(40)
                }
                addWidget(lblTitle)
				
				txtLog2 = new QTextEdit(win){setReadOnly(true)setText("Ready-2 to start...")}
                addWidget(txtLog2)

                // oChartWidget = new StockChart( win)
                // addWidget(oChartWidget)
            }
            setLayout(frameLayout)
        }

        # Add widgets to layouts
        controlsLayout.addWidget(groupControls)
        
        contentLayout.addWidget(groupData)
        contentLayout.addWidget(groupChart)
        contentLayout.setStretch(0, 1) # Log   takes 1 part
        contentLayout.setStretch(1, 2) # Chart takes 2 parts

        mainLayout.addLayout(controlsLayout)
        mainLayout.addLayout(contentLayout)

        setLayout(mainLayout)
        show()
    }
 }
 
    App.exec()
 

//=================================================================

//======================================
# "Select Ticker File", ".", "INI Files (*.ini);;All Files (*.*)") 

Func browseFile1(win)
    new QFileDialog(win) {
        cFile1 = getOpenFileName(win, "Select Ticker File", "", "INI Files (*.ini);;All Files (*.*)")
        if cFile1 != ""
                                   
            pos          = subStr(cFile1, "Quotes" )    // Strip Path upto Quotes-xxx.ini
            cInFileName1 = subStr(cFile1, pos )
			See "Quotes1: "+ cInFileName1 +nl
			
            txtTickerFile1.setText(cInFileName1 )       // Display It
            

        ok
    }
return	

//====================================== 
	
Func browseFile2(win)
    new QFileDialog(win) {
        cFile2 = getOpenFileName(win, "Select Ticker File", "", "INI Files (*.ini);;All Files (*.*)")
        if cFile2 != ""
                        
            pos          = subStr(cFile2, "Quotes" )    // Strip Path upto Quotes-xxx.ini
            cInFileName2 = subStr(cFile2, pos )
			See "Quotes2: "+ cInFileName2 +nl
			
            txtTickerFile2.setText(cInFileName2 )       // Display It
            
            
        ok
    }
return

// ----------------------------------------------------------------
# =================================================================
# =================================================================


Func GetQuotes()
     pOpen()
	 Diff(aList1, aList2)
	 
return

# ===========================================
# aList = sort(str2List(read("words.txt")))

Func pOpen()
		
	aList1 = str2List( read(cFile1) )
	aList2 = str2List( read(cFile2) )

return

# ============================

# =========================================================
# Find(List,ItemValue,nColumn,cAttribute) ---> Item Index

Func Diff(aList1, aList2)

    txtLog.clear()        
    txtLog2.clear()  
    
	len1 = len(aList1)
	len2 = len(aList2)
	
    See nl+ copy("=",30) + nl
	See "List1: "+ cInFileName1 + nl
    see "List1: Not found in aList2:" + nl
	
	    txtLog.append(copy("=",30) )
	    txtLog.append("List1: "+ cInFileName1 )
	    txtLog.append("List1: Not found in aList2:")
	    
	
    # --- Does item in List1 exist in List2
    for i = 1 to len1
	    itemValue = aList1[i]
        itemIndex = find(aList2, itemValue)
		
		if itemIndex = 0
		    See ""+ itemValue +nl       // Not Found Item in List 2
			txtLog.append(itemValue)
			Add (NotInList2, itemValue)
		else  
		    // See "    Found in aList2 itemValue: "+ itemValue +" Pos: "+ itemIndex +nl
		ok		
	next	
	
	
    See nl+ copy("=",30) + nl
	See "List2: "+ cInFileName2 + nl
    see "List2: Not found in aList1:" + nl	
	
		txtLog.append(copy("=",30) )
	    txtLog.append("List2: "+ cInFileName1 )
	    txtLog.append("List2: Not found in aList1:" )

    # --- Does item in List2 exist in List1
    for i = 1 to len2
	    itemValue = aList2[i]
        itemIndex = find(aList1, itemValue)
		
		if itemIndex = 0
		    See ""+ itemValue +nl         // Not Found Item in List 1
			txtLog.append(itemValue)
			Add (NotInList1, itemValue)
		else  
		    // See "    Found in aList1 itemValue: "+ itemValue +" Pos: "+ itemIndex +nl
		ok		
	next

    see nl+ copy("=",30) + nl
	
	# --------------------------
	
    # --- Update New List--- Show on Right panel ----------------------
	lenN1 = len(NotInList1)
	lenN2 = len(NotInList2)	
	
    // -------------
    aNewList1 = aList1
    for i = 1 to lenN1
	    ADD( aNewList1, NotInList1[i])
	next 
	

    aNewList2 = aList2
    for i = 1 to lenN2
	    ADD( aNewList2, NotInList2[i])
	next	
 
    // ----------------
	// Right Panel aNewList1
		
	txtLog2.append(copy("=",30) )
	for i = 1 to len(aNewList1)
        txtLog2.append(aNewList1[i])
	next


# =============================	
