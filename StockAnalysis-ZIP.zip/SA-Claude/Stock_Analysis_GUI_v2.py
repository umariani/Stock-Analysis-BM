"""
Stock Analysis Engine  –  GUI Edition  (with integrated Quote Fetcher)
================================================================================
Requires:
    pip install pandas numpy matplotlib yfinance requests

Usage:
    python stock_analysis_gui.py

On first run, click "⬇ Fetch Quotes" to download data from Yahoo Finance and
generate AAA-Spread.csv, then "▶ Run Analysis" to run the backtest engine.
You can also Browse to an existing AAA-Spread.csv and run directly.

Ticker list is read from Quotes-Mega-250.ini (same folder as this script).
"""

import os
import sys
import time
import threading
import warnings
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import numpy as np
import pandas as pd
from itertools import product

import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

warnings.filterwarnings("ignore")

# ── yfinance (optional – only needed for Fetch Quotes) ───────────────────────
try:
    import yfinance as yf
    _YF_AVAILABLE = True
except ImportError:
    _YF_AVAILABLE = False

# ── Colour palette ─────────────────────────────────────────────────────────
BG        = "#ffffff"
PANEL     = "#f3f4f6"
BORDER    = "#d1d5db"
ACCENT    = "#1d6fc4"
GREEN     = "#16803c"
RED       = "#dc2626"
YELLOW    = "#b45309"
TEXT      = "#111827"
MUTED     = "#6b7280"
FONT_MAIN = ("Consolas", 12)
FONT_HEAD = ("Consolas", 13, "bold")
FONT_BIG  = ("Consolas", 20, "bold")

# ── Fetcher defaults ───────────────────────────────────────────────────────
_DIR         = os.path.dirname(os.path.abspath(__file__))
DEFAULT_INI  = os.path.join(_DIR, "Quotes-Mega-250.ini")
DEFAULT_OUT  = os.path.join(_DIR, "AAA-Spread.csv")
DEFAULT_RNG  = "5y"
BATCH_SIZE   = 25
RETRY_MAX    = 3
RETRY_DELAY  = 4


# ══════════════════════════════════════════════════════════════════════════════
#  QUOTE FETCHER  (formerly fetch_quotes.py)
# ══════════════════════════════════════════════════════════════════════════════

def fq_read_tickers(ini_path):
    """Read ticker symbols from a plain-text .ini file (one ticker per line).
    QQQ and SPY are always injected at the top if not already present."""
    if not os.path.exists(ini_path):
        raise FileNotFoundError(f"Ticker file not found: {ini_path}")
    tickers = []
    with open(ini_path, "r") as fh:
        for line in fh:
            t = line.strip()
            if t and not t.startswith("#"):
                tickers.append(t)
    # Always ensure benchmark indices are present at the top
    for idx in ("SPY", "QQQ"):
        if idx not in tickers:
            tickers.insert(0, idx)
    return tickers


def fq_download_batch(tickers, period, attempt=1, interval="1mo"):
    """Download one batch of Open prices via yfinance."""
    try:
        raw = yf.download(
            tickers,
            period=period,
            interval=interval,
            auto_adjust=True,
            progress=False,
            threads=True,
            timeout=30,
        )
        if raw.empty:
            return None

        if len(tickers) == 1:
            opens = raw[["Open"]].copy()
            opens.columns = pd.MultiIndex.from_tuples([("Open", tickers[0])])
        else:
            opens = raw["Open"].copy() if "Open" in raw.columns else raw.xs("Open", axis=1, level=0)

        return opens

    except Exception as exc:
        return None


def fq_download_all(tickers, period, log_cb, interval="1mo"):
    """
    Download Open prices for all tickers in batches.
    Returns DataFrame: rows=dates, cols=tickers.
    """
    batches = [tickers[i:i+BATCH_SIZE] for i in range(0, len(tickers), BATCH_SIZE)]
    frames  = []

    for b_idx, batch in enumerate(batches, 1):
        log_cb(f"  Batch {b_idx}/{len(batches)}  ({len(batch)} tickers) ...")
        df = None
        for attempt in range(1, RETRY_MAX + 1):
            df = fq_download_batch(batch, period, attempt, interval=interval)
            if df is not None:
                break
            if attempt < RETRY_MAX:
                log_cb(f"    Retrying in {RETRY_DELAY}s ...")
                time.sleep(RETRY_DELAY)

        if df is None:
            log_cb(f"  WARNING: Batch {b_idx} failed after {RETRY_MAX} attempts — skipping")
            continue

        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(1)

        frames.append(df)
        time.sleep(0.5)

    if not frames:
        raise RuntimeError("No data downloaded — check internet connection.")

    combined = pd.concat(frames, axis=1)
    combined = combined.loc[:, ~combined.columns.duplicated()]
    return combined


def fq_fetch_live_prices(tickers, log_cb):
    """
    Fetch today's live price for each ticker using multiple fallback strategies.
    Returns dict {ticker: price}.
    """
    live = {}
    log_cb("Fetching live prices ...")

    # Method 1: batch 5d/1d download
    batches = [tickers[i:i+BATCH_SIZE] for i in range(0, len(tickers), BATCH_SIZE)]
    for b_idx, batch in enumerate(batches, 1):
        try:
            raw = yf.download(
                batch,
                period="5d",
                interval="1d",
                auto_adjust=True,
                progress=False,
                threads=True,
                timeout=20,
            )
            if raw.empty:
                continue

            if isinstance(raw.columns, pd.MultiIndex):
                closes = raw["Close"]
            else:
                closes = raw[["Close"]]
                closes.columns = batch[:1]

            for tk in closes.columns:
                series = closes[tk].dropna()
                if not series.empty:
                    live[tk] = float(series.iloc[-1])

        except Exception:
            pass

        if b_idx % 3 == 0:
            log_cb(f"  Live batch {b_idx}/{len(batches)} done ...")
        time.sleep(0.3)

    # Method 2: per-ticker fallback for missing
    missing = [tk for tk in tickers if tk not in live]
    if missing:
        log_cb(f"  Fallback: fetching {len(missing)} missing tickers individually ...")
        for tk in missing:
            for attempt in range(1, 3):
                try:
                    hist = yf.Ticker(tk).history(period="5d", interval="1d")
                    if not hist.empty:
                        live[tk] = float(hist["Close"].dropna().iloc[-1])
                        break
                except Exception:
                    pass
                time.sleep(0.2)
            if tk not in live:
                live[tk] = np.nan

    # Method 3: fast_info for anything still NaN
    still_nan = [tk for tk in tickers if np.isnan(live.get(tk, np.nan))]
    if still_nan:
        for tk in still_nan:
            try:
                fi = yf.Ticker(tk).fast_info
                for attr in ("last_price", "regularMarketPrice", "previous_close"):
                    val = getattr(fi, attr, None)
                    if val and float(val) > 0:
                        live[tk] = float(val)
                        break
            except Exception:
                live[tk] = np.nan

    fetched = sum(1 for v in live.values() if not np.isnan(v))
    log_cb(f"  Live prices fetched: {fetched}/{len(tickers)}")
    failed = [tk for tk in tickers if np.isnan(live.get(tk, np.nan))]
    if failed:
        log_cb(f"  WARNING: No live price for: {failed}")
        log_cb("  These will use their last monthly close instead.")
    return live


def fq_clean_prices(df, log_cb, min_months_ratio=0.5):
    """
    Clean monthly price DataFrame:
      1. Coerce to float
      2. Drop all-NaN tickers
      3. Forward/backward fill gaps
      4. Pad short-history tickers on the left
      5. Fill any residual NaN with column median
    """
    df = df.apply(pd.to_numeric, errors="coerce")
    n_total = len(df)

    all_nan = df.columns[df.isna().all()].tolist()
    if all_nan:
        log_cb(f"  Dropping {len(all_nan)} tickers with NO data: {all_nan}")
        df = df.drop(columns=all_nan)

    null_counts = df.isna().sum()
    bad = null_counts[null_counts > 0]
    if len(bad):
        log_cb(f"  Tickers with nulls before fix: {len(bad)}")

    df = df.ffill().bfill()

    max_months = n_total
    short = []
    for tk in df.columns:
        valid = df[tk].notna().sum()
        if valid < max_months * min_months_ratio:
            first_valid = df[tk].dropna().iloc[0] if df[tk].notna().any() else np.nan
            df[tk] = df[tk].fillna(first_valid)
            short.append(tk)

    if short:
        log_cb(f"  Padded {len(short)} short-history tickers")

    still_null = df.isna().sum()
    still_null = still_null[still_null > 0]
    if len(still_null):
        log_cb(f"  Filling {len(still_null)} tickers with residual NaN using median")
        df = df.fillna(df.median())

    log_cb(f"  Clean shape: {df.shape[0]} months × {df.shape[1]} tickers")
    return df


def fq_append_live_column(df, live_prices, log_cb):
    """Append one extra row at the bottom with today's live prices."""
    live_row = {}
    for tk in df.columns:
        lp = live_prices.get(tk, np.nan)
        live_row[tk] = lp if (not np.isnan(lp)) else df[tk].iloc[-1]

    live_df = pd.DataFrame([live_row], index=["live"])
    result  = pd.concat([df, live_df])
    log_cb(f"  Appended live-price row  →  total rows: {len(result)}")
    return result


def fq_write_csv(df, tickers_ordered, out_path, log_cb):
    """Write AAA-Spread.csv: one row per ticker, prices oldest→newest."""
    lines   = []
    skipped = []

    for tk in tickers_ordered:
        if tk not in df.columns:
            skipped.append(tk)
            continue
        prices = df[tk].values
        price_strs = [f"{p:.2f}" for p in prices]
        lines.append(f"{tk}, " + ", ".join(price_strs))

    if skipped:
        log_cb(f"  WARNING: Skipped {len(skipped)} tickers (no data): {skipped}")

    with open(out_path, "w") as fh:
        fh.write("\n".join(lines) + "\n")

    log_cb(f"  Written: {out_path}")
    log_cb(f"  Rows: {len(lines)} tickers  |  Cols: {df.shape[0]} price columns")


def fq_validate_csv(out_path, expected_tickers, log_cb):
    """Quick sanity check on the written CSV file."""
    log_cb("\n── Validation ─────────────────────────────────")
    rows = []
    with open(out_path) as fh:
        for line in fh:
            parts = [p.strip() for p in line.strip().split(",")]
            rows.append((parts[0], len(parts) - 1))

    col_counts = set(c for _, c in rows)
    log_cb(f"  Rows (tickers): {len(rows)}")
    log_cb(f"  Col counts seen: {sorted(col_counts)}")

    bad = []
    with open(out_path) as fh:
        for line in fh:
            parts = line.strip().split(",")
            tk = parts[0].strip()
            for v in parts[1:]:
                try:
                    f = float(v.strip())
                    if f <= 0:
                        bad.append(tk)
                        break
                except ValueError:
                    bad.append(tk)
                    break
    if bad:
        log_cb(f"  WARNING: Tickers with zero/negative/non-numeric prices: {bad}")
    else:
        log_cb("  All prices positive  ✓")

    missing = [t for t in expected_tickers if t not in [r[0] for r in rows]]
    if missing:
        log_cb(f"  WARNING: Missing from output: {missing}")
    else:
        log_cb(f"  All {len(expected_tickers)} tickers present  ✓")

    log_cb("────────────────────────────────────────────────\n")


def run_fetch_quotes(ini_path, out_path, period, interval, no_live, log_cb, done_cb, err_cb):
    """
    Full fetch pipeline – meant to run on a background thread.

    Parameters
    ----------
    ini_path : str   Path to ticker .ini file
    out_path : str   Destination AAA-Spread.csv
    period   : str   yfinance period string e.g. "5y"
    interval : str   yfinance interval string e.g. "1mo", "1wk", "1d"
    no_live  : bool  Skip live-price fetch when True
    log_cb   : callable(str)   Send a log line to the GUI
    done_cb  : callable(str)   Called on success with out_path
    err_cb   : callable(str)   Called on error with message
    """
    try:
        log_cb("=" * 50)
        log_cb("  Stock Quote Fetcher")
        log_cb("=" * 50)
        log_cb(f"  INI      : {ini_path}")
        log_cb(f"  OUT      : {out_path}")
        log_cb(f"  Range    : {period}")
        log_cb(f"  Interval : {interval}")
        log_cb("")

        # 1. Read tickers
        tickers = fq_read_tickers(ini_path)
        log_cb(f"Loaded {len(tickers)} tickers from {os.path.basename(ini_path)}")

        # 2. Download opens at chosen interval
        interval_labels = {"1mo": "monthly", "1wk": "weekly", "1d": "daily"}
        interval_label  = interval_labels.get(interval, interval)
        log_cb(f"\nDownloading {period} {interval_label} Open prices ...")
        df_monthly = fq_download_all(tickers, period, log_cb, interval=interval)
        log_cb(f"  Raw shape: {df_monthly.shape[0]} months × {df_monthly.shape[1]} tickers")

        # 3. Live prices
        if no_live:
            live_prices = {tk: np.nan for tk in tickers}
            log_cb("Skipping live prices (no-live mode)")
        else:
            live_prices = fq_fetch_live_prices(df_monthly.columns.tolist(), log_cb)

        # 4. Clean
        log_cb("\nCleaning data ...")
        df_clean = fq_clean_prices(df_monthly, log_cb)

        # 5. Append live row
        df_final = fq_append_live_column(df_clean, live_prices, log_cb)

        # 6. Write
        log_cb(f"\nWriting {os.path.basename(out_path)} ...")
        fq_write_csv(df_final, tickers, out_path, log_cb)

        # 7. Validate
        fq_validate_csv(out_path, tickers, log_cb)

        log_cb("Fetch complete.  AAA-Spread.csv is ready.")
        done_cb(out_path)

    except Exception as e:
        err_cb(str(e))


# ══════════════════════════════════════════════════════════════════════════════
#  DATA & ANALYSIS  (unchanged from original stock_analysis_gui.py)
# ══════════════════════════════════════════════════════════════════════════════

def load_csv(path):
    rows = []
    with open(path, "r") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split(",")]
            sym = parts[0]
            prices = []
            for p in parts[1:]:
                try:
                    prices.append(float(p))
                except ValueError:
                    prices.append(np.nan)
            rows.append((sym, prices))

    max_len = max(len(r[1]) for r in rows)
    padded  = []
    for sym, pr in rows:
        if len(pr) < max_len:
            pr = [pr[0]] * (max_len - len(pr)) + pr
        padded.append([sym] + pr)

    df_raw = pd.DataFrame(padded)
    df_raw.columns = ["ticker"] + list(range(max_len))
    df_raw = df_raw.set_index("ticker").apply(pd.to_numeric, errors="coerce")
    df_raw = df_raw.ffill(axis=1).bfill(axis=1)
    prices = df_raw.T
    prices.index = range(len(prices))
    return prices


# ══════════════════════════════════════════════════════════════════════════════
#  RANKING ALGORITHMS
#  Each function receives `prices` (DataFrame, rows=months, cols=tickers),
#  `t` (current month index), `range_mth` (lookback window), and returns a
#  pandas Series of scores (higher = better) indexed by ticker.
# ══════════════════════════════════════════════════════════════════════════════

def _score_momentum(prices, t, range_mth):
    """Original: current vs price range_mth months ago."""
    p_start = prices.iloc[t - range_mth]
    p_end   = prices.iloc[t]
    return (p_end / p_start.replace(0, np.nan)).fillna(0)


def _score_avg_momentum(prices, t, range_mth):
    """
    Current month vs EVERY prior month in the window, averaged.
    Captures the full shape of momentum rather than just endpoints.
    """
    p_end = prices.iloc[t]
    scores = []
    for k in range(1, range_mth + 1):
        p_ref = prices.iloc[t - k]
        scores.append((p_end / p_ref.replace(0, np.nan)).fillna(0))
    return pd.concat(scores, axis=1).mean(axis=1)


def _score_all_pairs_momentum(prices, t, range_mth):
    """
    7-month-ago price vs every subsequent month, summed.
    Rewards stocks whose 7m-ago price has been consistently below all following.
    """
    p_base = prices.iloc[t - range_mth]
    scores = []
    for k in range(range_mth - 1, 0, -1):
        p_ref = prices.iloc[t - k]
        scores.append((p_ref / p_base.replace(0, np.nan)).fillna(0))
    # include current month
    scores.append((prices.iloc[t] / p_base.replace(0, np.nan)).fillna(0))
    return pd.concat(scores, axis=1).mean(axis=1)


def _score_macd(prices, t, range_mth):
    """
    MACD-inspired score: fast EMA (3m) minus slow EMA (range_mth months).
    Higher = more bullish momentum signal.
    """
    fast_span = max(3, range_mth // 3)
    slow_span = range_mth
    window = prices.iloc[max(0, t - slow_span * 2): t + 1]
    if len(window) < slow_span:
        return _score_momentum(prices, t, range_mth)
    ema_fast = window.ewm(span=fast_span, adjust=False).mean().iloc[-1]
    ema_slow = window.ewm(span=slow_span, adjust=False).mean().iloc[-1]
    macd_line = ema_fast - ema_slow
    # Normalise by slow EMA so it's a relative %, not absolute dollars
    slow_val = ema_slow.replace(0, np.nan)
    return (macd_line / slow_val).fillna(0)


def _score_sharpe_momentum(prices, t, range_mth):
    """
    Rolling Sharpe-style score: mean monthly return / std over the window.
    Risk-adjusted momentum – penalises volatile spikes.
    """
    start_idx = max(0, t - range_mth)
    window = prices.iloc[start_idx: t + 1]
    if len(window) < 3:
        return _score_momentum(prices, t, range_mth)
    rets = window.pct_change().dropna()
    if len(rets) < 2:
        return _score_momentum(prices, t, range_mth)
    mu  = rets.mean()
    std = rets.std().replace(0, np.nan)
    return (mu / std).fillna(0)


def _score_moving_average(prices, t, range_mth):
    """
    Current price vs its own rolling mean over the window.
    Score = how far above (%) the moving average the stock currently is.
    """
    start_idx = max(0, t - range_mth)
    window = prices.iloc[start_idx: t + 1]
    ma    = window.mean()
    p_now = prices.iloc[t]
    ma_safe = ma.replace(0, np.nan)
    return ((p_now - ma_safe) / ma_safe).fillna(0)


def _score_composite(prices, t, range_mth):
    """
    Composite (equal-weight rank blend) of Momentum + Sharpe + MACD + MA.
    Normalises each to a [0,1] rank before blending to reduce outlier dominance.
    """
    def rank_norm(s):
        r = s.rank(pct=True)
        return r.fillna(0)

    s_mom    = rank_norm(_score_momentum(prices, t, range_mth))
    s_sharpe = rank_norm(_score_sharpe_momentum(prices, t, range_mth))
    s_macd   = rank_norm(_score_macd(prices, t, range_mth))
    s_ma     = rank_norm(_score_moving_average(prices, t, range_mth))
    s_avg    = rank_norm(_score_avg_momentum(prices, t, range_mth))

    return (s_mom + s_sharpe + s_macd + s_ma + s_avg) / 5.0


RANKING_ALGORITHMS = {
    "Momentum (original)":      _score_momentum,
    "Avg Momentum (all months)": _score_avg_momentum,
    "All-Pairs Momentum":       _score_all_pairs_momentum,
    "MACD":                     _score_macd,
    "Sharpe Momentum":          _score_sharpe_momentum,
    "Moving Average Cross":     _score_moving_average,
    "Composite (blend)":        _score_composite,
}

DEFAULT_ALGORITHM = "Momentum (original)"


# ══════════════════════════════════════════════════════════════════════════════
#  BACKTEST  (algorithm-aware)
# ══════════════════════════════════════════════════════════════════════════════

def backtest(prices, range_mth, top_k, algorithm=DEFAULT_ALGORITHM):
    score_fn = RANKING_ALGORITHMS.get(algorithm, _score_momentum)
    n     = len(prices)
    start = range_mth + 1

    port_compound = 1.0
    qqq_start     = prices.iloc[start]["QQQ"] if "QQQ" in prices.columns else None
    port_vals, qqq_vals, monthly_rets, top_history = [], [], [], []

    for t in range(start, n - 1):
        scores  = score_fn(prices, t, range_mth)
        ranked  = scores.nlargest(top_k).index.tolist()
        top_history.append(ranked)

        gains = []
        for tk in ranked:
            b = prices.iloc[t][tk]
            s = prices.iloc[t + 1][tk]
            if b > 0:
                gains.append(s / b)

        avg = np.mean(gains) if gains else 1.0
        port_compound *= avg
        monthly_rets.append(avg)
        port_vals.append(port_compound)

        if qqq_start and qqq_start > 0:
            qqq_vals.append(prices.iloc[t + 1]["QQQ"] / qqq_start)
        else:
            qqq_vals.append(np.nan)

    port  = pd.Series(port_vals)
    qqq   = pd.Series(qqq_vals)

    tot    = port_compound - 1
    qret   = qqq.iloc[-1] - 1 if len(qqq) > 0 else np.nan
    ratio  = (tot / qret) if qret and qret != 0 else np.nan
    n_mo   = len(monthly_rets)
    cagr   = port_compound ** (12 / max(n_mo, 1)) - 1
    std    = np.std([r - 1 for r in monthly_rets])
    sharpe = (np.mean([r - 1 for r in monthly_rets]) / std * np.sqrt(12)) if std > 0 else np.nan

    peak, max_dd = (port_vals[0] if port_vals else 1), 0
    for v in port_vals:
        if v > peak:
            peak = v
        dd = (peak - v) / peak
        if dd > max_dd:
            max_dd = dd

    stats = dict(
        range_mth    = range_mth,
        top_k        = top_k,
        algorithm    = algorithm,
        total_return = round(tot * 100, 2),
        qqq_return   = round(qret * 100, 2) if not np.isnan(qret) else 0.0,
        ratio        = round(ratio, 3)       if not np.isnan(ratio) else 0.0,
        cagr         = round(cagr * 100, 2),
        sharpe       = round(sharpe, 3)      if not np.isnan(sharpe) else 0.0,
        max_drawdown = round(max_dd * 100, 2),
        months_traded= n_mo,
    )
    return port, qqq, pd.Series(monthly_rets), top_history[-1] if top_history else [], stats


def grid_search(prices, range_vals, topk_vals, progress_cb=None,
                algorithms=None):
    """
    Grid search over (range_mth × top_k × algorithm).
    Pass algorithms=None to search all, or a list of names to restrict.
    """
    if algorithms is None:
        algorithms = list(RANKING_ALGORITHMS.keys())
    results = []
    combos  = list(product(range_vals, topk_vals, algorithms))
    for i, (rm, tk, algo) in enumerate(combos):
        _, _, _, _, stats = backtest(prices, rm, tk, algorithm=algo)
        results.append(stats)
        if progress_cb:
            progress_cb(int((i + 1) / len(combos) * 100))
    df = pd.DataFrame(results).sort_values("total_return", ascending=False)
    return df


def stock_contribution(prices, range_mth, top_k, algorithm=DEFAULT_ALGORITHM):
    score_fn = RANKING_ALGORITHMS.get(algorithm, _score_momentum)
    n, ticks = len(prices), prices.columns.tolist()
    start = range_mth + 1
    cnt   = {tk: 0  for tk in ticks}
    gains = {tk: [] for tk in ticks}
    for t in range(start, n - 1):
        perf    = score_fn(prices, t, range_mth)
        ranked  = perf.nlargest(top_k).index.tolist()
        for tk in ranked:
            cnt[tk] += 1
            b = prices.iloc[t][tk]
            s = prices.iloc[t + 1][tk]
            if b > 0:
                gains[tk].append(s / b - 1)
    rows = []
    for tk in ticks:
        g = gains[tk]
        rows.append(dict(
            ticker           = tk,
            appearances      = cnt[tk],
            avg_monthly_gain = round(np.mean(g) * 100, 2) if g else 0,
            compound_gain    = round((np.prod([1 + x for x in g]) - 1) * 100, 2) if g else 0,
        ))
    return pd.DataFrame(rows).sort_values("compound_gain", ascending=False)


def last_n_months_holdings(prices, range_mth, top_k, n_months=6,
                           algorithm=DEFAULT_ALGORITHM):
    score_fn = RANKING_ALGORITHMS.get(algorithm, _score_momentum)
    n = len(prices)
    records = []
    for offset, t in enumerate(range(n - n_months - 1, n - 1)):
        perf    = score_fn(prices, t, range_mth)
        ranked  = perf.nlargest(top_k)
        month_num = offset + 1
        for rank, (tk, perf_val) in enumerate(ranked.items(), 1):
            bp = prices.iloc[t][tk]
            sp = prices.iloc[t + 1][tk]
            gain_pct = (sp / bp - 1) * 100 if bp > 0 else 0
            records.append(dict(
                month         = month_num,
                rank          = rank,
                ticker        = tk,
                trailing_perf = round((perf_val - 1) * 100, 1),
                buy_price     = round(bp, 2),
                sell_price    = round(sp, 2),
                gain_pct      = round(gain_pct, 2),
            ))
    return pd.DataFrame(records)


def yearly_performance(prices, range_mth, top_k, algorithm=DEFAULT_ALGORITHM):
    """
    Compute calendar-year and current-YTD returns for the portfolio vs QQQ.
    Returns a list of dicts: {year, port_return, qqq_return, spy_return, is_ytd}.
    Months are assumed to be sequential starting from (today - n_months) ago.
    We approximate by mapping price rows to calendar months using today's date.
    """
    import datetime
    score_fn = RANKING_ALGORITHMS.get(algorithm, _score_momentum)
    n = len(prices)
    start = range_mth + 1

    today      = datetime.date.today()
    # The last row is "live" / current month; walk back to assign calendar months
    # Index n-1 = current month, n-2 = last month, etc.
    def row_to_date(row_idx):
        months_ago = (n - 1) - row_idx
        month = today.month - months_ago
        year  = today.year
        while month <= 0:
            month += 12
            year  -= 1
        return datetime.date(year, month, 1)

    # Build monthly returns for portfolio and QQQ/SPY
    port_month_rets = {}   # date -> portfolio multiplier
    qqq_month_rets  = {}
    spy_month_rets  = {}

    for t in range(start, n - 1):
        perf    = score_fn(prices, t, range_mth)
        ranked  = perf.nlargest(top_k).index.tolist()

        gains = []
        for tk in ranked:
            b = prices.iloc[t][tk]
            s = prices.iloc[t + 1][tk]
            if b > 0:
                gains.append(s / b)
        avg = np.mean(gains) if gains else 1.0

        d = row_to_date(t + 1)  # return is realised at t+1
        port_month_rets[d] = avg

        if "QQQ" in prices.columns:
            b = prices.iloc[t]["QQQ"]
            s = prices.iloc[t + 1]["QQQ"]
            qqq_month_rets[d] = (s / b) if b > 0 else 1.0
        if "SPY" in prices.columns:
            b = prices.iloc[t]["SPY"]
            s = prices.iloc[t + 1]["SPY"]
            spy_month_rets[d] = (s / b) if b > 0 else 1.0

    # Aggregate by calendar year
    import datetime
    all_dates = sorted(port_month_rets.keys())
    if not all_dates:
        return []

    years_seen = sorted(set(d.year for d in all_dates))
    current_year = today.year
    rows = []

    for yr in years_seen:
        yr_dates = [d for d in all_dates if d.year == yr]
        is_ytd   = (yr == current_year)

        port_ret = (np.prod([port_month_rets[d] for d in yr_dates]) - 1) * 100
        qqq_ret  = (np.prod([qqq_month_rets.get(d, 1.0)  for d in yr_dates]) - 1) * 100
        spy_ret  = (np.prod([spy_month_rets.get(d, 1.0)  for d in yr_dates]) - 1) * 100

        rows.append(dict(
            year       = str(yr) + (" YTD" if is_ytd else ""),
            port_return= round(port_ret, 2),
            qqq_return = round(qqq_ret,  2),
            spy_return = round(spy_ret,  2),
            is_ytd     = is_ytd,
        ))

    return rows


# ══════════════════════════════════════════════════════════════════════════════
#  HELPER WIDGETS
# ══════════════════════════════════════════════════════════════════════════════

def styled_frame(parent, **kw):
    kw.setdefault("bg", PANEL)
    kw.setdefault("highlightbackground", BORDER)
    kw.setdefault("highlightthickness", 1)
    return tk.Frame(parent, **kw)


def label(parent, text, font=FONT_MAIN, fg=TEXT, bg=PANEL, **kw):
    return tk.Label(parent, text=text, font=font, fg=fg, bg=bg, **kw)


def section_label(parent, text):
    f = tk.Frame(parent, bg=PANEL)
    tk.Label(f, text=text, font=FONT_HEAD, fg=ACCENT, bg=PANEL).pack(side="left")
    tk.Frame(f, bg=BORDER, height=1).pack(side="left", fill="x", expand=True, padx=(8, 0))
    return f


def stat_card(parent, title, value, color=TEXT):
    f = styled_frame(parent, padx=12, pady=8)
    tk.Label(f, text=title, font=("Consolas", 11), fg=MUTED, bg=PANEL).pack(anchor="w")
    tk.Label(f, text=value, font=("Consolas", 18, "bold"), fg=color, bg=PANEL).pack(anchor="w")
    return f


def dark_combo(parent, values, default=0, width=8):
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Dark.TCombobox",
        fieldbackground=PANEL, background=PANEL,
        foreground=TEXT, selectbackground=PANEL,
        selectforeground=ACCENT, arrowcolor=MUTED,
        bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER)
    cb = ttk.Combobox(parent, values=values, width=width,
                      state="readonly", style="Dark.TCombobox",
                      font=FONT_MAIN)
    cb.current(default)
    return cb


def dark_button(parent, text, command, color=ACCENT):
    return tk.Button(parent, text=text, command=command,
                     font=FONT_MAIN, fg=BG, bg=color,
                     activebackground=TEXT, activeforeground=BG,
                     relief="flat", padx=12, pady=4, cursor="hand2")


# ══════════════════════════════════════════════════════════════════════════════
#  MATPLOTLIB HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def make_figure(nrows=1, ncols=1, figsize=(10, 4)):
    fig = Figure(figsize=figsize, facecolor=BG)
    axes = []
    for i in range(nrows * ncols):
        ax = fig.add_subplot(nrows, ncols, i + 1)
        ax.set_facecolor(PANEL)
        ax.tick_params(colors=MUTED, labelsize=10)
        for spine in ax.spines.values():
            spine.set_edgecolor(BORDER)
        ax.xaxis.label.set_color(MUTED)
        ax.yaxis.label.set_color(MUTED)
        ax.title.set_color(TEXT)
        ax.grid(True, color=BORDER, linewidth=0.5, linestyle="--", alpha=0.5)
        axes.append(ax)
    fig.tight_layout(pad=2.0)
    return fig, axes


def embed_figure(fig, parent):
    canvas = FigureCanvasTkAgg(fig, master=parent)
    canvas.draw()
    toolbar = NavigationToolbar2Tk(canvas, parent, pack_toolbar=False)
    toolbar.config(bg=PANEL)
    toolbar._message_label.config(bg=PANEL, fg=MUTED)
    for btn in toolbar.winfo_children():
        try:
            btn.config(bg=PANEL, fg=MUTED, activebackground=BORDER)
        except Exception:
            pass
    toolbar.pack(side="bottom", fill="x")
    canvas.get_tk_widget().pack(fill="both", expand=True)
    return canvas


# ══════════════════════════════════════════════════════════════════════════════
#  FETCH QUOTES DIALOG
# ══════════════════════════════════════════════════════════════════════════════

class FetchDialog(tk.Toplevel):
    """
    Modal dialog to configure and launch the quote-fetch pipeline.
    Provides INI path, output path, date range, and no-live toggle.
    Progress is streamed into a scrollable log pane inside the dialog.
    """

    def __init__(self, parent, default_ini, default_out, on_success):
        super().__init__(parent)
        self.title("Fetch Quotes from Yahoo Finance")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.geometry("680x520")
        self.minsize(560, 400)
        self.grab_set()           # modal

        self._on_success = on_success
        self._running    = False

        # ── Form ──────────────────────────────────────────────────────────────
        form = styled_frame(self, padx=14, pady=10)
        form.pack(fill="x", padx=10, pady=(10, 0))

        def row(lbl_text, var, browse_cmd=None, width=44):
            r = tk.Frame(form, bg=PANEL)
            r.pack(fill="x", pady=3)
            tk.Label(r, text=lbl_text, font=FONT_MAIN, fg=MUTED,
                     bg=PANEL, width=12, anchor="e").pack(side="left", padx=(0, 6))
            e = tk.Entry(r, textvariable=var, font=FONT_MAIN, fg=TEXT, bg=BG,
                         insertbackground=TEXT, relief="flat",
                         highlightbackground=BORDER, highlightthickness=1,
                         width=width)
            e.pack(side="left", padx=(0, 4))
            if browse_cmd:
                dark_button(r, "Browse", browse_cmd, color=BORDER).pack(side="left")
            return e

        self.ini_var = tk.StringVar(value=default_ini)
        self.out_var = tk.StringVar(value=default_out)
        row("Ticker INI:", self.ini_var, self._browse_ini)
        row("Output CSV:", self.out_var, self._browse_out)

        # Range + no-live in one row
        opt_row = tk.Frame(form, bg=PANEL)
        opt_row.pack(fill="x", pady=3)
        tk.Label(opt_row, text="History:", font=FONT_MAIN, fg=MUTED, bg=PANEL,
                 width=12, anchor="e").pack(side="left", padx=(0, 6))
        self.cb_range = dark_combo(opt_row, ["1y","2y","5y","10y","max"], default=1, width=6)
        self.cb_range.pack(side="left", padx=(0, 16))

        tk.Label(opt_row, text="Interval:", font=FONT_MAIN, fg=MUTED,
                 bg=PANEL).pack(side="left", padx=(0, 6))
        self.cb_interval = dark_combo(
            opt_row,
            ["Monthly", "Weekly", "Daily"],
            default=0, width=9)
        self.cb_interval.pack(side="left", padx=(0, 20))

        self.no_live_var = tk.BooleanVar(value=False)
        tk.Checkbutton(opt_row, text="Skip live prices  (faster / offline)",
                       variable=self.no_live_var,
                       font=FONT_MAIN, fg=TEXT, bg=PANEL,
                       activebackground=PANEL, selectcolor=BG).pack(side="left")

        # ── Buttons ───────────────────────────────────────────────────────────
        btn_row = tk.Frame(self, bg=BG)
        btn_row.pack(fill="x", padx=10, pady=8)
        self.fetch_btn = dark_button(btn_row, "⬇  Start Fetch", self._start_fetch, color=ACCENT)
        self.fetch_btn.pack(side="left", padx=(0, 8))
        dark_button(btn_row, "✕  Close", self.destroy, color=BORDER).pack(side="left")

        self.progress = ttk.Progressbar(self, mode="indeterminate")
        style = ttk.Style()
        style.configure("Dark.Horizontal.TProgressbar",
            troughcolor=PANEL, background=ACCENT, borderwidth=0, thickness=3)
        self.progress.configure(style="Dark.Horizontal.TProgressbar")
        self.progress.pack(fill="x", padx=10)

        # ── Log pane ──────────────────────────────────────────────────────────
        log_frame = styled_frame(self)
        log_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        section_label(log_frame, "Fetch Log").pack(fill="x", padx=8, pady=(6, 2))

        self.log_text = tk.Text(log_frame, font=("Consolas", 11), fg=MUTED, bg=BG,
                                relief="flat", state="disabled",
                                wrap="word", padx=8, pady=6)
        sb = tk.Scrollbar(log_frame, command=self.log_text.yview, bg=PANEL,
                          troughcolor=PANEL, width=10)
        self.log_text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log_text.pack(fill="both", expand=True, padx=(6, 0), pady=(0, 8))

    # ── Browse helpers ────────────────────────────────────────────────────────
    def _browse_ini(self):
        p = filedialog.askopenfilename(
            title="Select ticker .ini file",
            filetypes=[("INI files", "*.ini"), ("All files", "*.*")])
        if p:
            self.ini_var.set(p)

    def _browse_out(self):
        p = filedialog.asksaveasfilename(
            title="Save AAA-Spread.csv as",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if p:
            self.out_var.set(p)

    # ── Log helper ────────────────────────────────────────────────────────────
    def _log(self, text):
        def _do():
            self.log_text.config(state="normal")
            self.log_text.insert("end", text + "\n")
            self.log_text.see("end")
            self.log_text.config(state="disabled")
        self.after(0, _do)

    # ── Start / finish fetch ──────────────────────────────────────────────────
    def _start_fetch(self):
        if not _YF_AVAILABLE:
            messagebox.showerror(
                "yfinance not installed",
                "Install yfinance first:\n\n    pip install yfinance",
                parent=self)
            return

        ini  = self.ini_var.get().strip()
        out  = self.out_var.get().strip()
        rng  = self.cb_range.get()
        nlive = self.no_live_var.get()

        # Map human-readable label → yfinance interval string
        _interval_map = {"Monthly": "1mo", "Weekly": "1wk", "Daily": "1d"}
        interval = _interval_map.get(self.cb_interval.get(), "1mo")

        if not ini or not os.path.exists(ini):
            messagebox.showerror("File not found",
                                 f"Ticker INI not found:\n{ini}", parent=self)
            return
        if not out:
            messagebox.showerror("No output path",
                                 "Please specify an output CSV path.", parent=self)
            return

        self._running = True
        self.fetch_btn.config(state="disabled")
        self.progress.start(12)

        threading.Thread(
            target=run_fetch_quotes,
            args=(ini, out, rng, interval, nlive, self._log, self._fetch_done, self._fetch_err),
            daemon=True
        ).start()

    def _fetch_done(self, out_path):
        def _do():
            self.progress.stop()
            self.fetch_btn.config(state="normal")
            self._running = False
            self._log("\n✓ Done!  Click Close to return to the main window.")
            self._on_success(out_path)
        self.after(0, _do)

    def _fetch_err(self, msg):
        def _do():
            self.progress.stop()
            self.fetch_btn.config(state="normal")
            self._running = False
            self._log(f"\n✗ ERROR: {msg}")
            messagebox.showerror("Fetch Error", msg, parent=self)
        self.after(0, _do)


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ══════════════════════════════════════════════════════════════════════════════

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Stock Analyzer")
        self.configure(bg=BG)
        self.geometry("1300x820")
        self.minsize(1100, 720)

        # State
        self.csv_path    = tk.StringVar()
        self.ini_path    = tk.StringVar(value=DEFAULT_INI)
        self.prices      = None
        self.df_res      = None
        self.df_stocks   = None
        self.df_holdings = None
        self.df_yearly   = None
        self.port_curve  = None
        self.qqq_curve   = None
        self.best_stats  = None
        self.top_last    = []

        # Stock Charts tab state
        self._sc_tickers  = []   # ordered list for the listbox (Ranked or Alpha)
        self._sc_idx      = 0    # currently selected index
        self._sc_order    = tk.StringVar(value="Ranked")
        self.top_ranked_all = []  # full last-period ranking, all tickers

        # Try to auto-detect CSV beside the script
        auto = os.path.join(_DIR, "AAA-Spread.csv")
        if os.path.exists(auto):
            self.csv_path.set(auto)

        self._build_ui()

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Top toolbar
        toolbar = tk.Frame(self, bg=PANEL, pady=6)
        toolbar.pack(fill="x", padx=0, pady=0)
        self._build_toolbar(toolbar)

        # Notebook tabs
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Dark.TNotebook", background=BG, borderwidth=0)
        style.configure("Dark.TNotebook.Tab",
            background=PANEL, foreground=MUTED,
            font=FONT_MAIN, padding=(14, 6),
            borderwidth=0)
        style.map("Dark.TNotebook.Tab",
            background=[("selected", BG)],
            foreground=[("selected", ACCENT)])

        nb = ttk.Notebook(self, style="Dark.TNotebook")
        nb.pack(fill="both", expand=True, padx=0, pady=0)

        self.tab_overview  = tk.Frame(nb, bg=BG)
        self.tab_curve     = tk.Frame(nb, bg=BG)
        self.tab_grid      = tk.Frame(nb, bg=BG)
        self.tab_stocks    = tk.Frame(nb, bg=BG)
        self.tab_holdings  = tk.Frame(nb, bg=BG)
        self.tab_yearly    = tk.Frame(nb, bg=BG)
        self.tab_stkcharts = tk.Frame(nb, bg=BG)

        nb.add(self.tab_overview,  text="  Overview  ")
        nb.add(self.tab_curve,     text="  Portfolio Curve  ")
        nb.add(self.tab_grid,      text="  Algorithm Grid  ")
        nb.add(self.tab_stocks,    text="  Stock Contributions  ")
        nb.add(self.tab_holdings,  text="  Last 6 Months  ")
        nb.add(self.tab_yearly,    text="  Yearly vs QQQ  ")
        nb.add(self.tab_stkcharts, text="  Stock Charts  ")

        self._build_overview(self.tab_overview)
        self._build_curve_tab(self.tab_curve)
        self._build_grid_tab(self.tab_grid)
        self._build_stocks_tab(self.tab_stocks)
        self._build_holdings_tab(self.tab_holdings)
        self._build_yearly_tab(self.tab_yearly)
        self._build_stkcharts_tab(self.tab_stkcharts)

        # Status bar
        self.status_var = tk.StringVar(value="Click '⬇ Fetch Quotes' to download data, or browse to an existing CSV.")
        status = tk.Label(self, textvariable=self.status_var,
                          font=("Consolas", 11), fg=MUTED, bg=PANEL,
                          anchor="w", padx=10)
        status.pack(fill="x", side="bottom")

        # Progress bar
        style.configure("Dark.Horizontal.TProgressbar",
            troughcolor=PANEL, background=ACCENT, borderwidth=0, thickness=3)
        self.progress = ttk.Progressbar(self, style="Dark.Horizontal.TProgressbar",
                                        mode="determinate")
        self.progress.pack(fill="x", side="bottom")

    def _build_toolbar(self, parent):
        # Logo / title
        tk.Label(parent, text="▲ StockAnalyser", font=("Consolas", 15, "bold"),
                 fg=ACCENT, bg=PANEL).pack(side="left", padx=(14, 20))

        # ── Fetch Quotes button (new) ─────────────────────────────────────────
        dark_button(parent, "⬇  Fetch Quotes", self._open_fetch_dialog,
                    color=ACCENT).pack(side="left", padx=(0, 16))

        tk.Label(parent, text="CSV:", font=FONT_MAIN, fg=MUTED, bg=PANEL).pack(side="left")
        tk.Entry(parent, textvariable=self.csv_path,
                 font=FONT_MAIN, fg=TEXT, bg=BG,
                 insertbackground=TEXT, relief="flat",
                 highlightbackground=BORDER, highlightthickness=1,
                 width=38).pack(side="left", padx=(4, 4))
        dark_button(parent, "Browse", self._browse_csv, color=BORDER).pack(side="left", padx=(0, 16))

        tk.Label(parent, text="Lookback:", font=FONT_MAIN, fg=MUTED, bg=PANEL).pack(side="left")
        self.cb_range = dark_combo(parent, ["3","5","6","7","9","12","16","20","24","28","32","36","40"], default=3, width=4)
        self.cb_range.pack(side="left", padx=(4, 12))

        tk.Label(parent, text="Top-K:", font=FONT_MAIN, fg=MUTED, bg=PANEL).pack(side="left")
        self.cb_topk = dark_combo(parent, ["5","7","10","12","15","20"], default=2, width=4)
        self.cb_topk.pack(side="left", padx=(4, 12))

        tk.Label(parent, text="Algorithm:", font=FONT_MAIN, fg=MUTED, bg=PANEL).pack(side="left")
        algo_names = list(RANKING_ALGORITHMS.keys())
        self.cb_algo = dark_combo(parent, algo_names, default=0, width=22)
        self.cb_algo.pack(side="left", padx=(4, 6))

        self.all_algos_var = tk.BooleanVar(value=False)
        tk.Checkbutton(parent, text="Grid all algos",
                       variable=self.all_algos_var,
                       font=("Consolas", 11), fg=TEXT, bg=PANEL,
                       activebackground=PANEL, selectcolor=BG).pack(side="left", padx=(0, 10))

        dark_button(parent, "▶  Run Analysis", self._run_analysis, color=GREEN).pack(side="left", padx=(0, 8))
        dark_button(parent, "⬇  Export CSVs",  self._export_csvs,  color=YELLOW).pack(side="left")

        # Run indicator dot
        self.run_indicator = tk.Label(parent, text="●", font=("Consolas", 16),
                                      fg=BORDER, bg=PANEL)
        self.run_indicator.pack(side="right", padx=14)

    # ── Overview tab ──────────────────────────────────────────────────────────
    def _build_overview(self, parent):
        pad = dict(padx=16, pady=10)

        # Stat cards row
        self.cards_frame = tk.Frame(parent, bg=BG)
        self.cards_frame.pack(fill="x", **pad)

        self.card_return  = stat_card(self.cards_frame, "Total Return",   "—",     TEXT)
        self.card_qqq     = stat_card(self.cards_frame, "QQQ Return",     "—",     TEXT)
        self.card_ratio   = stat_card(self.cards_frame, "Outperform ×",   "—",     TEXT)
        self.card_cagr    = stat_card(self.cards_frame, "Annual CAGR",    "—",     TEXT)
        self.card_sharpe  = stat_card(self.cards_frame, "Sharpe Ratio",   "—",     TEXT)
        self.card_dd      = stat_card(self.cards_frame, "Max Drawdown",   "—",     TEXT)

        for c in (self.card_return, self.card_qqq, self.card_ratio,
                  self.card_cagr, self.card_sharpe, self.card_dd):
            c.pack(side="left", expand=True, fill="both", padx=4)

        # Holdings + log side by side
        mid = tk.Frame(parent, bg=BG)
        mid.pack(fill="both", expand=True, **pad)

        # Current holdings
        left = styled_frame(mid)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        section_label(left, "Current Holdings").pack(fill="x", padx=10, pady=(8, 4))
        self.holdings_tree = self._make_tree(left,
            ("Rank","Ticker","7mo Perf %"), (50, 80, 100))
        self.holdings_tree.pack(fill="both", expand=True, padx=6, pady=(0, 8))

        # Log
        right = styled_frame(mid)
        right.pack(side="left", fill="both", expand=True)
        section_label(right, "Run Log").pack(fill="x", padx=10, pady=(8, 4))
        self.log_text = tk.Text(right, font=("Consolas", 11), fg=MUTED, bg=BG,
                                relief="flat", state="disabled",
                                wrap="word", padx=8, pady=6)
        sb = tk.Scrollbar(right, command=self.log_text.yview, bg=PANEL,
                          troughcolor=PANEL, width=10)
        self.log_text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log_text.pack(fill="both", expand=True, padx=(6, 0), pady=(0, 8))

    # ── Portfolio Curve tab ───────────────────────────────────────────────────
    def _build_curve_tab(self, parent):
        fig = Figure(figsize=(10, 5), facecolor=BG)
        self.ax_curve = fig.add_subplot(111)
        self.ax_curve.set_facecolor(PANEL)
        self.ax_curve.tick_params(colors=MUTED, labelsize=11)
        for sp in self.ax_curve.spines.values():
            sp.set_edgecolor(BORDER)
        self.ax_curve.grid(True, color=BORDER, linewidth=0.5, linestyle="--", alpha=0.5)
        fig.tight_layout(pad=2.5)
        self.fig_curve = fig
        embed_figure(fig, parent)

    # ── Algorithm Grid tab ────────────────────────────────────────────────────
    def _build_grid_tab(self, parent):
        top = tk.Frame(parent, bg=BG)
        top.pack(fill="both", expand=True, padx=16, pady=10)

        # Heatmap left
        left = styled_frame(top)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        section_label(left, "Total Return Heatmap (RangeMth × TopK)").pack(fill="x", padx=10, pady=(8, 4))

        fig = Figure(figsize=(5, 4), facecolor=BG)
        self.ax_heat = fig.add_subplot(111)
        self.ax_heat.set_facecolor(PANEL)
        self.ax_heat.tick_params(colors=MUTED, labelsize=11)
        for sp in self.ax_heat.spines.values():
            sp.set_edgecolor(BORDER)
        fig.tight_layout(pad=2.0)
        self.fig_heat = fig
        canvas = FigureCanvasTkAgg(fig, master=left)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=(0, 8))

        # Table right
        right = styled_frame(top)
        right.pack(side="left", fill="both", expand=True)
        section_label(right, "All Configurations").pack(fill="x", padx=10, pady=(8, 4))
        cols = ("Algorithm","RangeMth","TopK","Total Ret%","QQQ Ret%","Ratio","CAGR%","Sharpe","MaxDD%")
        self.grid_tree = self._make_tree(right, cols, (160,70,50,90,80,70,70,70,70))
        self.grid_tree.pack(fill="both", expand=True, padx=6, pady=(0, 8))

    # ── Stock Contributions tab ───────────────────────────────────────────────
    def _build_stocks_tab(self, parent):
        top = tk.Frame(parent, bg=BG)
        top.pack(fill="both", expand=True, padx=16, pady=10)

        left = styled_frame(top)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        section_label(left, "Top 20 by Compound Gain").pack(fill="x", padx=10, pady=(8, 4))

        fig = Figure(figsize=(5, 5), facecolor=BG)
        self.ax_stocks = fig.add_subplot(111)
        self.ax_stocks.set_facecolor(PANEL)
        self.ax_stocks.tick_params(colors=MUTED, labelsize=10)
        for sp in self.ax_stocks.spines.values():
            sp.set_edgecolor(BORDER)
        self.ax_stocks.grid(True, color=BORDER, linewidth=0.5, linestyle="--",
                            alpha=0.5, axis="x")
        fig.tight_layout(pad=2.0)
        self.fig_stocks = fig
        canvas = FigureCanvasTkAgg(fig, master=left)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=(0, 8))

        right = styled_frame(top)
        right.pack(side="left", fill="both", expand=True)
        section_label(right, "Full Stock Table").pack(fill="x", padx=10, pady=(8, 4))
        cols = ("Ticker","Appearances","Avg Mo Gain%","Compound Gain%")
        self.stocks_tree = self._make_tree(right, cols, (80, 100, 110, 120))
        self.stocks_tree.pack(fill="both", expand=True, padx=6, pady=(0, 8))

    # ── Last 6 Months tab ─────────────────────────────────────────────────────
    def _build_holdings_tab(self, parent):
        ctrl = tk.Frame(parent, bg=BG)
        ctrl.pack(fill="x", padx=16, pady=(10, 4))
        tk.Label(ctrl, text="Month:", font=FONT_MAIN, fg=MUTED, bg=BG).pack(side="left")
        self.cb_month = dark_combo(ctrl, ["1","2","3","4","5","6"], default=5, width=4)
        self.cb_month.pack(side="left", padx=(4, 0))
        self.cb_month.bind("<<ComboboxSelected>>", lambda e: self._refresh_holdings())

        self.month_avg_lbl = tk.Label(ctrl, text="", font=FONT_MAIN, fg=MUTED, bg=BG)
        self.month_avg_lbl.pack(side="left", padx=16)

        main = styled_frame(parent)
        main.pack(fill="both", expand=True, padx=16, pady=(0, 10))

        section_label(main, "Holdings — Buy / Sell / Gain").pack(fill="x", padx=10, pady=(8, 4))
        cols = ("#","Ticker","7mo Trail%","Buy Price","Sell Price","Gain/Loss%")
        self.h_tree = self._make_tree(main, cols, (40, 70, 100, 90, 90, 100))
        self.h_tree.pack(fill="both", expand=True, padx=6, pady=(0, 8))

    # ── Yearly vs QQQ tab ─────────────────────────────────────────────────────
    def _build_yearly_tab(self, parent):
        top = tk.Frame(parent, bg=BG)
        top.pack(fill="both", expand=True, padx=16, pady=10)

        # Chart on left
        left = styled_frame(top)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        section_label(left, "Annual Return: Portfolio vs QQQ vs SPY").pack(
            fill="x", padx=10, pady=(8, 4))

        fig = Figure(figsize=(6, 5), facecolor=BG)
        self.ax_yearly = fig.add_subplot(111)
        self.ax_yearly.set_facecolor(PANEL)
        self.ax_yearly.tick_params(colors=MUTED, labelsize=10)
        for sp in self.ax_yearly.spines.values():
            sp.set_edgecolor(BORDER)
        self.ax_yearly.grid(True, color=BORDER, linewidth=0.5,
                            linestyle="--", alpha=0.5, axis="y")
        fig.tight_layout(pad=2.0)
        self.fig_yearly = fig
        canvas = FigureCanvasTkAgg(fig, master=left)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=(0, 8))

        # Table on right
        right = styled_frame(top)
        right.pack(side="left", fill="both", expand=True)
        section_label(right, "Year-by-Year Results").pack(fill="x", padx=10, pady=(8, 4))
        cols = ("Year", "Portfolio %", "QQQ %", "SPY %", "vs QQQ", "vs SPY")
        self.yearly_tree = self._make_tree(right, cols, (80, 100, 80, 80, 90, 90))
        self.yearly_tree.pack(fill="both", expand=True, padx=6, pady=(0, 8))

    def _update_yearly_tab(self):
        if not self.df_yearly:
            return
        rows   = self.df_yearly
        ax     = self.ax_yearly
        ax.clear()
        ax.set_facecolor(PANEL)
        ax.tick_params(colors=MUTED, labelsize=10)
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        ax.grid(True, color=BORDER, linewidth=0.5, linestyle="--", alpha=0.5, axis="y")

        years     = [r["year"]        for r in rows]
        port_rets = [r["port_return"] for r in rows]
        qqq_rets  = [r["qqq_return"]  for r in rows]
        spy_rets  = [r["spy_return"]  for r in rows]

        x      = range(len(years))
        width  = 0.28
        offsets= [-width, 0, width]
        colors_list = [ACCENT, MUTED, YELLOW]
        labels = ["Portfolio", "QQQ", "SPY"]
        data_sets = [port_rets, qqq_rets, spy_rets]

        for off, color, lbl, data in zip(offsets, colors_list, labels, data_sets):
            positions = [xi + off for xi in x]
            bar_colors = [
                color if v >= 0 else RED
                for v in data
            ]
            ax.bar(positions, data, width=width, color=bar_colors,
                   label=lbl, alpha=0.88)

        ax.axhline(0, color=BORDER, linewidth=0.8)
        ax.set_xticks(list(x))
        ax.set_xticklabels(years, rotation=30, ha="right", fontsize=9, color=MUTED)
        ax.set_ylabel("Return %", color=MUTED)
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:.0f}%"))
        ax.set_title("Calendar Year Returns  (Portfolio / QQQ / SPY)", color=TEXT, pad=10)
        ax.legend(facecolor=PANEL, edgecolor=BORDER, labelcolor=TEXT, fontsize=10)

        self.fig_yearly.tight_layout(pad=2.0)
        self.fig_yearly.canvas.draw()

        # Table
        tree = self._tree_widget(self.yearly_tree)
        if tree:
            tree.delete(*tree.get_children())
            for r in rows:
                pr  = r["port_return"]
                qr  = r["qqq_return"]
                sr  = r["spy_return"]
                vs_q = pr - qr
                vs_s = pr - sr
                sign  = lambda v: ("+" if v >= 0 else "")
                tag   = "ytd" if r["is_ytd"] else ("pos" if pr >= qr else "neg")
                tree.insert("", "end", tags=(tag,), values=(
                    r["year"],
                    f"{sign(pr)}{pr:.1f}%",
                    f"{sign(qr)}{qr:.1f}%",
                    f"{sign(sr)}{sr:.1f}%",
                    f"{sign(vs_q)}{vs_q:.1f}%",
                    f"{sign(vs_s)}{vs_s:.1f}%",
                ))
            tree.tag_configure("pos",  foreground=GREEN)
            tree.tag_configure("neg",  foreground=RED)
            tree.tag_configure("ytd",  foreground=YELLOW)

    # ── Treeview helper ───────────────────────────────────────────────────────
    def _make_tree(self, parent, columns, widths):
        style = ttk.Style()
        style.configure("Dark.Treeview",
            background=BG, foreground=TEXT,
            fieldbackground=BG, rowheight=22,
            font=("Consolas", 11), borderwidth=0)
        style.configure("Dark.Treeview.Heading",
            background=PANEL, foreground=MUTED,
            font=("Consolas", 11, "bold"), relief="flat")
        style.map("Dark.Treeview",
            background=[("selected", BORDER)],
            foreground=[("selected", ACCENT)])

        frame = tk.Frame(parent, bg=BG)
        frame.pack_propagate(False)

        sb = tk.Scrollbar(frame, bg=PANEL, troughcolor=PANEL, width=10)
        tree = ttk.Treeview(frame, columns=columns, show="headings",
                            style="Dark.Treeview", yscrollcommand=sb.set)
        sb.config(command=tree.yview)
        sb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)

        for col, w in zip(columns, widths):
            tree.heading(col, text=col)
            anchor = "e" if col not in ("Ticker","ticker","#","Rank") else "w"
            tree.column(col, width=w, anchor=anchor, stretch=True)

        return frame  # return frame so .pack() works on caller

    def _tree_widget(self, frame):
        """Get the Treeview widget inside the frame."""
        for child in frame.winfo_children():
            if isinstance(child, ttk.Treeview):
                return child
        return None

    # ── Fetch Quotes dialog ───────────────────────────────────────────────────
    def _open_fetch_dialog(self):
        """Open the Fetch Quotes modal dialog."""
        FetchDialog(
            parent      = self,
            default_ini = self.ini_path.get() or DEFAULT_INI,
            default_out = self.csv_path.get() or DEFAULT_OUT,
            on_success  = self._on_fetch_success,
        )

    def _on_fetch_success(self, out_path):
        """Called (from main thread via after()) when fetch completes successfully."""
        self.csv_path.set(out_path)
        self._set_status(f"Quotes fetched → {out_path}  |  Click ▶ Run Analysis to continue.")
        self._log(f"Quotes saved to: {out_path}")

    # ── Browse ────────────────────────────────────────────────────────────────
    def _browse_csv(self):
        path = filedialog.askopenfilename(
            title="Select AAA-Spread.csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if path:
            self.csv_path.set(path)

    # ── Run Analysis ──────────────────────────────────────────────────────────
    def _run_analysis(self):
        path = self.csv_path.get().strip()
        if not path or not os.path.exists(path):
            messagebox.showerror("File not found",
                "Please select a valid AAA-Spread.csv file,\n"
                "or click '⬇ Fetch Quotes' to download fresh data.")
            return
        self.run_indicator.config(fg=YELLOW)
        self._log_clear()
        threading.Thread(target=self._run_worker, args=(path,), daemon=True).start()

    def _run_worker(self, path):
        try:
            self._log(f"Loading {path} ...")
            self.prices = load_csv(path)
            n_tickers = self.prices.shape[1]
            n_months  = self.prices.shape[0]
            self._log(f"  → {n_tickers} tickers | {n_months} months")

            rm   = int(self.cb_range.get())
            tk_  = int(self.cb_topk.get())
            algo = self.cb_algo.get()
            all_algos = self.all_algos_var.get()

            grid_algos = list(RANKING_ALGORITHMS.keys()) if all_algos else [algo]
            n_combos = 6 * 6 * len(grid_algos)
            self._log(f"\nRunning grid search ({n_combos} combos, {len(grid_algos)} algorithm(s)) ...")
            self._set_status("Running grid search...")

            self.df_res = grid_search(
                self.prices,
                [3, 5, 6, 7, 9, 12],
                [5, 7, 10, 12, 15, 20],
                progress_cb=lambda p: self._set_progress(p),
                algorithms=grid_algos,
            )
            self._log(f"  → {n_combos} combos done")

            best     = self.df_res.iloc[0]
            best_rm  = int(best.range_mth)
            best_tk  = int(best.top_k)
            best_algo = best.algorithm
            self._log(f"\nGrid best: RangeMth={best_rm}, TopK={best_tk}, Algorithm={best_algo}")
            self._log(f"  Total Return : {best.total_return:.2f}%")
            self._log(f"  QQQ Return   : {best.qqq_return:.2f}%")
            self._log(f"  Ratio        : {best.ratio:.3f}x")
            self._log(f"  CAGR         : {best.cagr:.2f}%")
            self._log(f"  Sharpe       : {best.sharpe:.3f}")
            self._log(f"  Max Drawdown : {best.max_drawdown:.2f}%")

            b_rm = rm
            b_tk = tk_
            self._log(f"\nRunning with selected: RangeMth={b_rm}, TopK={b_tk}, Algo={algo}")

            self.port_curve, self.qqq_curve, _, self.top_last, self.best_stats = \
                backtest(self.prices, b_rm, b_tk, algorithm=algo)

            # Full last-period ranking for Stock Charts tab
            score_fn = RANKING_ALGORITHMS.get(algo, _score_momentum)
            t = len(self.prices) - 2
            scores = score_fn(self.prices, t, b_rm)
            self.top_ranked_all = scores.sort_values(ascending=False).index.tolist()

            self._log("\nCalculating stock contributions ...")
            self.df_stocks   = stock_contribution(self.prices, b_rm, b_tk, algorithm=algo)
            self.df_holdings = last_n_months_holdings(self.prices, b_rm, b_tk, n_months=6,
                                                      algorithm=algo)
            self._log("Calculating yearly performance ...")
            self.df_yearly   = yearly_performance(self.prices, b_rm, b_tk, algorithm=algo)

            self._log("Done.")
            self.after(0, self._update_all_ui)

        except Exception as e:
            import traceback
            self._log(f"\nERROR: {e}")
            self._log(traceback.format_exc())
            self.after(0, lambda: self.run_indicator.config(fg=RED))
            self.after(0, lambda: self._set_status(f"Error: {e}"))

    # ── Update all UI after run ───────────────────────────────────────────────
    def _update_all_ui(self):
        self._update_stat_cards()
        self._update_holdings_overview()
        self._update_curve_chart()
        self._update_grid_tab()
        self._update_stocks_tab()
        self._refresh_holdings()
        self._update_yearly_tab()
        self._update_stkcharts_tab()
        self.run_indicator.config(fg=GREEN)
        s    = self.best_stats
        best = self.df_res.iloc[0]
        self._set_status(
            f"Selected: RangeMth={int(s['range_mth'])}, TopK={int(s['top_k'])}, "
            f"Algo={s.get('algorithm','?')}  |  "
            f"Total Return: {s['total_return']:.1f}%  |  QQQ: {s['qqq_return']:.1f}%  |  "
            f"Grid best: {best.algorithm} RangeMth={int(best.range_mth)}, TopK={int(best.top_k)} ({best.total_return:.1f}%)"
        )
        self._set_progress(0)

    def _update_stat_cards(self):
        s = self.best_stats
        for w in self.cards_frame.winfo_children():
            w.destroy()

        def mk(title, val, color):
            f = styled_frame(self.cards_frame, padx=12, pady=8)
            tk.Label(f, text=title, font=("Consolas", 11), fg=MUTED, bg=PANEL).pack(anchor="w")
            tk.Label(f, text=val,   font=("Consolas", 18, "bold"), fg=color, bg=PANEL).pack(anchor="w")
            f.pack(side="left", expand=True, fill="both", padx=4)

        tr = s["total_return"]
        mk("Total Return",  f"+{tr:.1f}%",                GREEN)
        mk("QQQ Return",    f"+{s['qqq_return']:.1f}%",   TEXT)
        mk("Outperform ×",  f"{s['ratio']:.2f}×",         ACCENT)
        mk("Annual CAGR",   f"{s['cagr']:.1f}%",          GREEN if s['cagr'] > 0 else RED)
        mk("Sharpe Ratio",  f"{s['sharpe']:.3f}",         ACCENT)
        mk("Max Drawdown",  f"-{s['max_drawdown']:.1f}%", RED)

    def _update_holdings_overview(self):
        tree = self._tree_widget(self.holdings_tree)
        if tree is None:
            return
        tree.delete(*tree.get_children())
        if self.prices is not None and self.top_last:
            rm = int(self.cb_range.get())
            n  = len(self.prices)
            t  = n - 1
            p_start = self.prices.iloc[t - rm]
            p_end   = self.prices.iloc[t]
            for i, tk_ in enumerate(self.top_last, 1):
                try:
                    ps   = p_start[tk_]
                    pe   = p_end[tk_]
                    perf = (pe / ps - 1) * 100 if ps > 0 else 0
                    tree.insert("", "end", values=(i, tk_, f"{perf:+.1f}%"))
                except Exception:
                    tree.insert("", "end", values=(i, tk_, "—"))

    # ── Stock Charts tab ──────────────────────────────────────────────────────
    def _build_stkcharts_tab(self, parent):
        """
        Left panel : order toggle (Ranked / Alpha) + scrollable ticker listbox
                     + Stk-PREV / Stk-NEXT navigation buttons.
        Right panel: matplotlib price chart for the selected ticker.
        """
        outer = tk.Frame(parent, bg=BG)
        outer.pack(fill="both", expand=True, padx=16, pady=10)

        # ── Left panel ──────────────────────────────────────────────────────
        left = styled_frame(outer, padx=6, pady=6)
        left.pack(side="left", fill="y", padx=(0, 10))
        left.pack_propagate(False)
        left.config(width=230)

        section_label(left, "Stocks").pack(fill="x", padx=4, pady=(4, 6))

        # Order toggle row
        order_row = tk.Frame(left, bg=PANEL)
        order_row.pack(fill="x", padx=4, pady=(0, 6))
        tk.Label(order_row, text="Order:", font=FONT_MAIN, fg=MUTED, bg=PANEL).pack(side="left")

        def _toggle_order():
            cur = self._sc_order.get()
            new = "Alpha" if cur == "Ranked" else "Ranked"
            self._sc_order.set(new)
            order_btn.config(text=new,
                             bg=ACCENT if new == "Ranked" else "#8b5cf6")
            self._sc_rebuild_listbox()

        order_btn = tk.Button(
            order_row, text="Ranked",
            font=FONT_MAIN, fg=BG, bg=ACCENT,
            activebackground=TEXT, activeforeground=BG,
            relief="flat", padx=8, pady=2, cursor="hand2",
            command=_toggle_order)
        order_btn.pack(side="left", padx=(6, 0))
        self._sc_order_btn = order_btn

        # Stk-PREV / Stk-NEXT navigation — placed just below Order row
        nav_row = tk.Frame(left, bg=PANEL)
        nav_row.pack(fill="x", padx=4, pady=(0, 6))
        dark_button(nav_row, "Stk-PREV", self._sc_prev, color="#8b5cf6").pack(
            side="left", expand=True, fill="x", padx=(0, 3))
        dark_button(nav_row, "Stk-NEXT", self._sc_next, color=ACCENT).pack(
            side="left", expand=True, fill="x", padx=(3, 0))

        # Listbox + scrollbar
        lb_frame = tk.Frame(left, bg=PANEL)
        lb_frame.pack(fill="both", expand=True, padx=4, pady=(0, 6))

        sb_lb = tk.Scrollbar(lb_frame, bg=PANEL, troughcolor=PANEL, width=10)
        self._sc_listbox = tk.Listbox(
            lb_frame,
            font=FONT_MAIN, fg=TEXT, bg=BG,
            selectbackground=ACCENT, selectforeground=BG,
            relief="flat", borderwidth=0,
            activestyle="none",
            yscrollcommand=sb_lb.set,
            exportselection=False,
        )
        sb_lb.config(command=self._sc_listbox.yview)
        sb_lb.pack(side="right", fill="y")
        self._sc_listbox.pack(fill="both", expand=True)
        self._sc_listbox.bind("<<ListboxSelect>>", self._sc_on_listbox_select)

        # ── Right panel – chart ──────────────────────────────────────────────
        right = styled_frame(outer)
        right.pack(side="left", fill="both", expand=True)

        fig = Figure(figsize=(9, 5), facecolor=BG)
        self.ax_stkcharts = fig.add_subplot(111)
        self.ax_stkcharts.set_facecolor(PANEL)
        self.ax_stkcharts.tick_params(colors=MUTED, labelsize=10)
        for sp in self.ax_stkcharts.spines.values():
            sp.set_edgecolor(BORDER)
        self.ax_stkcharts.grid(True, color=BORDER, linewidth=0.5,
                               linestyle="--", alpha=0.5)
        fig.tight_layout(pad=2.5)
        self.fig_stkcharts = fig
        self._sc_canvas = FigureCanvasTkAgg(fig, master=right)
        self._sc_canvas.draw()
        toolbar = NavigationToolbar2Tk(self._sc_canvas, right, pack_toolbar=False)
        toolbar.config(bg=PANEL)
        toolbar._message_label.config(bg=PANEL, fg=MUTED)
        for btn in toolbar.winfo_children():
            try:
                btn.config(bg=PANEL, fg=MUTED, activebackground=BORDER)
            except Exception:
                pass
        toolbar.pack(side="bottom", fill="x")
        self._sc_canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=(4, 0))

    def _update_stkcharts_tab(self):
        """Populate the listbox after a run and draw the first stock."""
        if self.prices is None:
            return
        self._sc_rebuild_listbox()

    def _sc_rebuild_listbox(self):
        """Rebuild the listbox in Ranked or Alpha order, preserving selection."""
        if self.prices is None:
            return
        all_tickers = [c for c in self.prices.columns
                       if c not in ("QQQ", "SPY")]

        if self._sc_order.get() == "Ranked":
            # Use the full last-period trailing-performance ranking —
            # the same sort the algorithm uses, so order matches Overview.
            if self.top_ranked_all:
                ranked     = self.top_ranked_all
                ranked_set = set(ranked)
                extras     = [t for t in all_tickers if t not in ranked_set]
                ordered    = ranked + extras
            else:
                ordered = all_tickers
        else:
            ordered = sorted(all_tickers)

        self._sc_tickers = ordered
        lb = self._sc_listbox
        lb.delete(0, "end")
        for i, tk_ in enumerate(ordered):
            lb.insert("end", f"{i+1:>3}. {tk_}")

        # Restore or default index
        self._sc_idx = min(self._sc_idx, max(0, len(ordered) - 1))
        if ordered:
            lb.selection_clear(0, "end")
            lb.selection_set(self._sc_idx)
            lb.see(self._sc_idx)
            self._sc_draw_chart(self._sc_idx)

    def _sc_on_listbox_select(self, event):
        sel = self._sc_listbox.curselection()
        if sel:
            self._sc_idx = sel[0]
            self._sc_draw_chart(self._sc_idx)

    def _sc_next(self):
        if not self._sc_tickers:
            return
        self._sc_idx = (self._sc_idx + 1) % len(self._sc_tickers)
        self._sc_listbox.selection_clear(0, "end")
        self._sc_listbox.selection_set(self._sc_idx)
        self._sc_listbox.see(self._sc_idx)
        self._sc_draw_chart(self._sc_idx)

    def _sc_prev(self):
        if not self._sc_tickers:
            return
        self._sc_idx = (self._sc_idx - 1) % len(self._sc_tickers)
        self._sc_listbox.selection_clear(0, "end")
        self._sc_listbox.selection_set(self._sc_idx)
        self._sc_listbox.see(self._sc_idx)
        self._sc_draw_chart(self._sc_idx)

    def _sc_draw_chart(self, idx):
        """Draw an actual-price chart for the ticker at position idx."""
        if self.prices is None or not self._sc_tickers:
            return
        ticker = self._sc_tickers[idx]
        ax = self.ax_stkcharts
        ax.clear()
        ax.set_facecolor(PANEL)
        ax.tick_params(colors=MUTED, labelsize=10)
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        ax.grid(True, which="major", axis="both", color="#000000",
                linewidth=0.5, linestyle="-", alpha=0.3)
        ax.minorticks_on()
        ax.grid(True, which="minor", axis="both", color="#000000",
                linewidth=0.2, linestyle="-", alpha=0.1)
        ax.set_axisbelow(True)

        price_series = self.prices[ticker].dropna()
        x            = range(len(price_series))
        vals         = price_series.values  # actual dollar prices

        # Month-to-date: last price vs previous month's price
        cur_price  = vals[-1]
        prev_price = vals[-2] if len(vals) >= 2 else vals[-1]
        mtd_chg    = cur_price - prev_price
        mtd_pct    = (mtd_chg / prev_price * 100) if prev_price > 0 else 0
        mtd_sign   = "+" if mtd_chg >= 0 else ""
        mtd_color  = GREEN if mtd_chg >= 0 else RED

        # Overall direction colours the fill and line
        line_color = GREEN if cur_price >= vals[0] else RED

        # Shade under the curve from the first price level
        base_level = vals[0]
        ax.fill_between(x, base_level, vals,
                        where=[v >= base_level for v in vals],
                        color=GREEN, alpha=0.08)
        ax.fill_between(x, base_level, vals,
                        where=[v < base_level for v in vals],
                        color=RED, alpha=0.08)

        ax.plot(x, vals, color=line_color, linewidth=1.8)
        ax.axhline(y=base_level, color=BORDER, linewidth=0.8, linestyle=":")

        # Y-axis: dollar format
        ax.yaxis.set_major_formatter(
            mticker.FuncFormatter(lambda v, _: f"${v:,.2f}"))
        ax.set_xlabel("Month", color=MUTED)
        ax.set_ylabel("Price ($)", color=MUTED)

        # Rank badge
        rank_str = f"  #{idx+1}" if self._sc_order.get() == "Ranked" else ""

        # Title: ticker  rank  current price  MTD change
        title = (f"{ticker}{rank_str}     "
                 f"${cur_price:,.2f}     "
                 f"MTD:  {mtd_sign}${mtd_chg:,.2f}  ({mtd_sign}{mtd_pct:.1f}%)")
        ax.set_title(title, color=TEXT, fontsize=12, fontweight="bold", pad=10)

        # Colour the MTD part of the title via a secondary text annotation
        # (title is one string so we mark the colour with the line color of MTD)
        ax.title.set_color(mtd_color if abs(mtd_pct) > 0.01 else TEXT)

        # QQQ overlay — also in actual dollars (secondary Y if scales differ a lot,
        # but simpler: just plot on same axis scaled to match the stock's range)
        if "QQQ" in self.prices.columns:
            qqq_series = self.prices["QQQ"].dropna()
            n          = min(len(qqq_series), len(price_series))
            qqq_vals   = qqq_series.values[:n]
            # Scale QQQ to start at the same price as the stock for visual comparison
            if qqq_vals[0] > 0 and vals[0] > 0:
                qqq_scaled = qqq_vals * (vals[0] / qqq_vals[0])
            else:
                qqq_scaled = qqq_vals
            ax.plot(range(n), qqq_scaled, color=MUTED, linewidth=1.0,
                    linestyle="--", alpha=0.7, label="QQQ (scaled)")
            ax.legend(facecolor=PANEL, edgecolor=BORDER,
                      labelcolor=TEXT, fontsize=10)

        self.fig_stkcharts.tight_layout(pad=2.5)
        self._sc_canvas.draw()

    def _update_curve_chart(self):
        ax = self.ax_curve
        ax.clear()
        ax.set_facecolor(PANEL)
        ax.tick_params(colors=MUTED, labelsize=11)
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        # Major grid – fine black lines on both axes
        ax.grid(True, which="major", axis="both", color="#000000",
                linewidth=0.6, linestyle="-", alpha=0.4)
        # Minor grid – fine, less black
        ax.minorticks_on()
        ax.xaxis.set_minor_locator(mticker.MultipleLocator(1))   # one line per month
        ax.yaxis.set_minor_locator(mticker.AutoMinorLocator())
        ax.grid(True, which="minor", axis="both", color="#000000",
                linewidth=0.3, linestyle="-", alpha=0.15)
        ax.set_axisbelow(True)

        x        = range(len(self.port_curve))
        port_pct = self.port_curve.values * 100
        qqq_pct  = self.qqq_curve.values * 100

        ax.plot(x, port_pct, color=ACCENT, linewidth=2.0,
                label=f"Portfolio (+{self.best_stats['total_return']:.0f}%)")
        ax.plot(x, qqq_pct,  color=MUTED,  linewidth=1.2, linestyle="--",
                label=f"QQQ (+{self.best_stats['qqq_return']:.0f}%)")
        ax.axhline(y=100, color=BORDER, linewidth=0.8, linestyle=":")
        ax.fill_between(x, 100, port_pct,
                        where=[v > 100 for v in port_pct],
                        color=ACCENT, alpha=0.07)

        ax.set_xlabel("Month", color=MUTED)
        ax.set_ylabel("Portfolio Value (base=100)", color=MUTED)
        ax.set_title(
            f"Portfolio vs QQQ  —  RangeMth={int(self.best_stats['range_mth'])}, "
            f"TopK={int(self.best_stats['top_k'])}, Algo={self.best_stats.get('algorithm','?')}",
            color=TEXT, pad=10)
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:.0f}%"))
        ax.legend(facecolor=PANEL, edgecolor=BORDER, labelcolor=TEXT, fontsize=11)

        self.fig_curve.tight_layout(pad=2.5)
        self.fig_curve.canvas.draw()

    def _update_grid_tab(self):
        ax = self.ax_heat
        ax.clear()
        ax.set_facecolor(PANEL)
        ax.tick_params(colors=MUTED, labelsize=10)
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)

        rm_vals = [3, 5, 6, 7, 9, 12]
        tk_vals = [5, 7, 10, 12, 15, 20]
        # Heatmap uses the best algorithm's slice for clean 6×6 display
        best_algo_name = self.df_res.iloc[0].algorithm
        df_slice = self.df_res[self.df_res.algorithm == best_algo_name]
        matrix  = np.zeros((len(rm_vals), len(tk_vals)))
        for i, rm in enumerate(rm_vals):
            for j, tk_ in enumerate(tk_vals):
                row = df_slice[
                    (df_slice.range_mth == rm) & (df_slice.top_k == tk_)
                ]
                if len(row):
                    matrix[i, j] = row.iloc[0].total_return

        ax.imshow(matrix, cmap="YlOrRd", aspect="auto")
        ax.set_xticks(range(len(tk_vals)))
        ax.set_yticks(range(len(rm_vals)))
        ax.set_xticklabels([str(v) for v in tk_vals], color=MUTED)
        ax.set_yticklabels([f"{v}mo" for v in rm_vals], color=MUTED)
        ax.set_xlabel("Top-K", color=MUTED)
        ax.set_ylabel("RangeMth", color=MUTED)
        ax.set_title(f"Total Return %  [{best_algo_name}]", color=TEXT)

        for i in range(len(rm_vals)):
            for j in range(len(tk_vals)):
                ax.text(j, i, f"{matrix[i,j]:.0f}",
                        ha="center", va="center",
                        color=TEXT, fontsize=9, fontweight="bold")

        best_rm = int(self.df_res.iloc[0].range_mth)
        best_tk = int(self.df_res.iloc[0].top_k)
        try:
            bi = rm_vals.index(best_rm)
            bj = tk_vals.index(best_tk)
        except ValueError:
            bi, bj = 0, 0
        from matplotlib.patches import Rectangle
        rect = Rectangle((bj - 0.5, bi - 0.5), 1, 1,
                          linewidth=2, edgecolor=ACCENT, facecolor="none")
        ax.add_patch(rect)

        self.fig_heat.tight_layout(pad=2.0)
        self.fig_heat.canvas.draw()

        tree = self._tree_widget(self.grid_tree)
        if tree:
            tree.delete(*tree.get_children())
            best_algo = self.df_res.iloc[0].algorithm
            for _, row in self.df_res.iterrows():
                tag = "best" if (row.range_mth == best_rm and row.top_k == best_tk
                                 and row.algorithm == best_algo) else ""
                tree.insert("", "end", tags=(tag,), values=(
                    row.algorithm,
                    int(row.range_mth), int(row.top_k),
                    f"{row.total_return:.1f}%",
                    f"{row.qqq_return:.1f}%",
                    f"{row.ratio:.3f}",
                    f"{row.cagr:.1f}%",
                    f"{row.sharpe:.3f}",
                    f"{row.max_drawdown:.1f}%",
                ))
            tree.tag_configure("best", foreground=ACCENT)

    def _update_stocks_tab(self):
        ax = self.ax_stocks
        ax.clear()
        ax.set_facecolor(PANEL)
        ax.tick_params(colors=MUTED, labelsize=10)
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        ax.grid(True, color=BORDER, linewidth=0.5, linestyle="--", alpha=0.5, axis="x")

        top20  = self.df_stocks.head(20)
        labels = top20["ticker"].tolist()[::-1]
        gains  = top20["compound_gain"].tolist()[::-1]
        colors = [GREEN if g > 0 else RED for g in gains]

        ax.barh(labels, gains, color=colors, height=0.6)
        ax.set_xlabel("Compound Gain %", color=MUTED)
        ax.set_title("Stock Compound Gains (Best Algorithm)", color=TEXT)
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f"{v:.0f}%"))

        self.fig_stocks.tight_layout(pad=2.0)
        self.fig_stocks.canvas.draw()

        tree = self._tree_widget(self.stocks_tree)
        if tree:
            tree.delete(*tree.get_children())
            for _, row in self.df_stocks.iterrows():
                cg  = row["compound_gain"]
                tag = "pos" if cg > 0 else "neg"
                tree.insert("", "end", tags=(tag,), values=(
                    row["ticker"],
                    int(row["appearances"]),
                    f"{row['avg_monthly_gain']:.2f}%",
                    f"{cg:.2f}%",
                ))
            tree.tag_configure("pos", foreground=GREEN)
            tree.tag_configure("neg", foreground=RED)

    def _refresh_holdings(self):
        if self.df_holdings is None:
            return
        m    = int(self.cb_month.get())
        sub  = self.df_holdings[self.df_holdings["month"] == m]
        avg  = sub["gain_pct"].mean()
        sign = "+" if avg >= 0 else ""
        color = GREEN if avg >= 0 else RED
        self.month_avg_lbl.config(
            text=f"Avg gain: {sign}{avg:.2f}%", fg=color)

        tree = self._tree_widget(self.h_tree)
        if tree is None:
            return
        tree.delete(*tree.get_children())
        for _, row in sub.iterrows():
            gp   = row["gain_pct"]
            tag  = "pos" if gp >= 0 else "neg"
            sign = "+" if gp >= 0 else ""
            tree.insert("", "end", tags=(tag,), values=(
                int(row["rank"]),
                row["ticker"],
                f"+{row['trailing_perf']:.1f}%",
                f"${row['buy_price']:.2f}",
                f"${row['sell_price']:.2f}",
                f"{sign}{gp:.2f}%",
            ))
        tree.tag_configure("pos", foreground=GREEN)
        tree.tag_configure("neg", foreground=RED)

    # ── Export CSVs ───────────────────────────────────────────────────────────
    def _export_csvs(self):
        if self.df_res is None:
            messagebox.showwarning("No data", "Run the analysis first.")
            return
        folder = filedialog.askdirectory(title="Select export folder")
        if not folder:
            return
        try:
            self.df_res.to_csv(
                os.path.join(folder, "grid_search_results.csv"), index=False)
            self.df_stocks.to_csv(
                os.path.join(folder, "stock_contributions.csv"), index=False)
            self.df_holdings.to_csv(
                os.path.join(folder, "last_6_months_holdings.csv"), index=False)
            pd.DataFrame({"portfolio": self.port_curve.values,
                          "qqq": self.qqq_curve.values}).to_csv(
                os.path.join(folder, "portfolio_curve.csv"), index=False)
            messagebox.showinfo("Exported", f"4 CSV files saved to:\n{folder}")
        except PermissionError:
            messagebox.showerror("Permission Error",
                "Close the CSV files in Excel first, then try again.")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    # ── Logging ───────────────────────────────────────────────────────────────
    def _log(self, text):
        def _do():
            self.log_text.config(state="normal")
            self.log_text.insert("end", text + "\n")
            self.log_text.see("end")
            self.log_text.config(state="disabled")
        self.after(0, _do)

    def _log_clear(self):
        self.log_text.config(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.config(state="disabled")

    def _set_status(self, text):
        self.after(0, lambda: self.status_var.set(text))

    def _set_progress(self, value):
        self.after(0, lambda: self.progress.config(value=value))


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = App()
    app.mainloop()
    
    
    
###  The 7 ranking algorithms — how they compare
###  
###  1. Momentum (original) — price[now] / price[7mo ago]
###  Simple endpoint-to-endpoint. 
###  Fast, but blind to the path. 
###  A stock that crashed 6 months ago and recovered looks identical to one that rose steadily.
###  
###  2. Avg Momentum (all months) — mean(price[now] / price[each prior month])
###  Compares today's price against every month in the window and averages. 
###  Rewards consistent risers over the whole period rather than just the endpoints. 
###  Often smoother than plain momentum.
###  
###  3. All-Pairs Momentum — mean(price[month k] / price[7mo ago]) for all k
###  Your "7 months ago vs every following month" idea — 
###  it rewards stocks whose base price has been consistently below all subsequent months. 
###  Good at catching sustained trends vs recoveries.
###  
###  4. MACD — (fast EMA − slow EMA) / slow EMA
###  Classic trend-following signal. 
###  The fast EMA (≈ lookback/3) crossing above the slow EMA signals acceleration. 
###  On monthly data it's less noisy than daily, so it tends to lag less than you'd expect.
###  
###  5. Sharpe Momentum — mean monthly return / std of returns
###  Risk-adjusted momentum. 
###  A stock up 30% on one wild month scores lower than one up 5% every month. 
###  Tends to produce lower drawdowns and better Sharpe ratios at the cost of sometimes missing explosive movers.
###  
###  6. Moving Average Cross — (price[now] − MA) / MA
###  How far above its own rolling mean is the stock right now? 
###  Filters out level differences and focuses purely on deviation from trend. 
###  Works well as a mean-reversion avoidance signal.
###  
###  7. Composite (blend) — equal-weight rank average of all five above
###  Each algorithm's raw scores are converted to percentile ranks first (0→1), then averaged. 
###  This kills outlier dominance and tends to produce more stable, diversified picks. 
###  Often not the highest return but frequently the best risk-adjusted result over multiple market regimes.
###  
###  What to expect on your real data
###  On random synthetic data the differences are small, which is expected. 
###  On real momentum-driven markets (2019–2021, 2023–2024) 
###  MACD and Sharpe Momentum typically beat plain momentum. 
###  In choppy/mean-reverting periods Composite tends to hold up better. 
###  Run "Grid all algos" once and the table will rank all 252 combos — that's the most honest answer for your specific dataset and time range.
###  
###  Stock analysis gui v2PY DownloadYou said: What is the "All Pairs Momentum" ?
###  What is the "All Pairs Momentum" ?7:35 a.m.
###  Claude responded: All-Pairs Momentum — explained
###  All-Pairs Momentum — explained
###  Your original algorithm does one comparison per month:
###  score = price[today] / price[7 months ago]
###  One snapshot. Two endpoints. Everything in between is ignored.
###  
###  All-Pairs Momentum uses the 7-month-ago price as a baseline and then measures how far every subsequent month has risen above it:
###  score = mean of:
###      price[6mo ago] / price[7mo ago]
###      price[5mo ago] / price[7mo ago]
###      price[4mo ago] / price[7mo ago]
###      price[3mo ago] / price[7mo ago]
###      price[2mo ago] / price[7mo ago]
###      price[1mo ago] / price[7mo ago]
###      price[today]   / price[7mo ago]
###  It then averages all those ratios into a single score.
###  
###  Why that distinction matters
###  Consider two stocks that both end up +20% after 7 months:
###  MonthStock AStock B−7mo (base)100100−6mo10285−5mo10580−4mo10878−3mo11290−2mo115105−1mo118115Today120120
###  Plain momentum scores them identically — both are 120/100 = 1.20.
###  All-Pairs Momentum scores Stock A much higher, because it was consistently above its baseline for the entire window. Stock B spent most of the period below its starting price and only recovered late — a much riskier momentum story.
###  
###  The intuition
###  It's asking: "Has this stock been strong the whole time, or did it just get lucky at the end?"
###  A stock that scores well here has been in a sustained uptrend throughout the lookback window — not a V-shape recovery, not a last-minute spike. That sustained strength tends to reflect genuine institutional buying pressure rather than a short squeeze or a one-month pop.You said: Thankyou.Thankyou. goodbye7:53 a.m.Claude responded: Goodbye!Goodbye! Good luck with the backtesting — hope the new algorithms give you some useful signals. 👋Sonnet 4.6 Low    
